# Stream-K paper notes (Sec. 4-5, arXiv:2301.03598)

- work unit = one MAC-loop iteration, BLK_M x BLK_N x BLK_K
- total_iters = tiles_m * tiles_n * iters_per_tile, iters_per_tile = ceil(k/BLK_K)
- iters_per_cta = ceil(total_iters / g) -- every CTA gets this, last one gets the leftover
- linearized m -> n -> k, so a CTA's range can cross tile boundaries
- fixup: CTA that starts a tile (k=0) owns it, writes C. others just
  store partial + signal. owner waits on peers, sums, writes.
- hybrid (Sec 5.2, what they actually benchmark): do whole-tile
  data-parallel rounds first, Stream-K-split only the leftover tiles
  that don't fill a full round -- "two-tile" sizing so each leftover
  tile has at most 2 contributing CTAs (simpler fixup, 1 peer).

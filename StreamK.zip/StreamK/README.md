# Stream-K Prototype — Container-Distributed Matrix Multiplication

A standalone prototype implementing a **work-centric** (Stream-K style)
distribution strategy for matrix multiplication across TCP-connected
worker containers, built to benchmark against this group's other
algorithm candidates for CSC-4770/5770 Project 1.

## What "Stream-K style" means here

Classic tile-based distribution splits the *output matrix* into tiles
and hands whole tiles to workers. When the tile count doesn't divide
evenly across workers, some sit idle while others are still finishing
— exactly the bottleneck risk the project's non-functional requirements
warn about.

This prototype instead:

1. Treats every output tile's full K-dimension (reduction) depth as a
   pool of "work units" — `total_units = num_tiles * K`.
2. Splits that flat pool into N **equal contiguous shares**, one per
   worker, **without regard for tile boundaries**. A worker's share
   may be a partial K-range of one tile, a whole tile, or several
   tiles — whatever keeps the shares even.
3. Sends each worker its share as a batch of `(tile, k_start, k_end)`
   assignments over a plain TCP socket.
4. Each worker computes its partial product for its assigned K-slice
   only, and returns it.
5. The coordinator **sums partial results that share a tile** across
   different k-ranges to reconstruct the full output.

This is adapted from the Stream-K algorithm (Osama, Merrill, Cecka,
Garland, Owens, *"Stream-K: Work-centric Parallel Decomposition for
Dense Matrix-Matrix Multiplication on the GPU"*, arXiv:2301.03598,
2023) — the original targets GPU streaming multiprocessors sharing
fast on-chip memory. This prototype substitutes **Docker containers
communicating over TCP sockets** as the "physical processing
elements," which is a materially different cost model (network
round-trips instead of near-free on-chip coordination) and is exactly
what we're measuring here.

## Scope note — why this is a prototype, not the final architecture

The project requires three separate microservices (input, multiplication,
aggregation), each in its own container. For this comparison
prototype, the input and aggregation roles are combined into a single
`coordinator.py` to keep the benchmarking harness simple while we
evaluate whether this distribution strategy is worth adopting. If the
group chooses Stream-K's approach for the final system, split
`coordinator.py` back into separate input and aggregation services
before submission.

## Files

| File | Role |
|---|---|
| `shared.py` | Length-prefixed JSON wire protocol used by all services |
| `worker.py` | Multiplication microservice — computes partial products for its assigned K-slices |
| `coordinator.py` | Input (splits work, Stream-K style) + aggregation (sums partials, verifies correctness) |
| `Dockerfile` | Container image for both worker and coordinator roles |
| `docker-compose.yml` | Spins up 4 worker containers + 1 coordinator run |

## Running locally (no Docker)

```bash
pip install -r requirements.txt

# start however many workers you want, each on its own port
python3 worker.py --port 9001 &
python3 worker.py --port 9002 &
python3 worker.py --port 9003 &
python3 worker.py --port 9004 &

# run the coordinator against them
python3 coordinator.py --M 512 --K 512 --N 512 --tile-size 128 \
    --workers localhost:9001 localhost:9002 localhost:9003 localhost:9004
```

Expected output: a per-worker work-unit count (should be within 1 of
perfectly even), a wall-clock time, and a correctness check against
`numpy`'s `A @ B`.

## Running with Docker

```bash
docker compose up --build worker1 worker2 worker3 worker4 -d
docker compose run --rm coordinator
```

Edit the `command:` block under `coordinator` in `docker-compose.yml`
to change matrix size, tile size, or worker count for different
benchmark runs.

## What to record for the algorithm comparison

For an apples-to-apples comparison against the group's other
candidates, run each matrix size/shape combination required by the
benchmarking plan (square vs. rectangular, varying sizes, container
counts of 2 and 4) and record:

- Wall-clock time (printed)
- Per-worker work-unit counts (printed — this is the evidence for
  "even workload distribution," not just an assumption)
- CPU/memory usage per container (use `docker stats` during a run)
- Repeat each configuration 10x and report mean/stdev per the team's
  reproducibility plan; set `--seed` for reproducible matrices

## Known limitations / next steps

- **Dense only.** This prototype does not yet implement sparse matrix
  handling — only numpy dense arrays are sent and multiplied.
- **Whole-matrix transmission.** Each worker currently receives the
  full row-block of A and full column-block of B needed for its
  tile(s), not a pre-sliced minimal payload. Fine at this scale;
  revisit if bandwidth becomes a bottleneck at 10,000×10,000.
- **No GEMM recursion.** Workers do a single flat `numpy` matmul on
  their assigned block, not a recursive divide-and-conquer split
  within the worker itself. Combine with the group's other
  divide-and-conquer logic if a hybrid approach is wanted.
- **No fault tolerance.** A dropped worker connection currently
  crashes the coordinator run; not addressed here since the rubric's
  error-handling requirement wasn't the focus of this prototype.

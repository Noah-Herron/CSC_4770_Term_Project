"""
coordinator.py — plays the divider AND aggregation roles for
this Stream-K prototype.

What this does:
  1. Generates (or loads) matrices A (M x K) and B (K x N).
  2. Lays out the output matrix C (M x N) as a grid of tiles.
  3. Computes TOTAL work units = (number of tiles) * K  — i.e. every
     tile's full reduction depth counted separately. This is the
     "aggregate inner loop iterations" Stream-K balances.
  4. Splits that flat sequence of work units into len(workers) equal
     contiguous shares — WITHOUT regard for tile boundaries. A share
     may span a partial k-range of one tile, a whole tile, or several
     tiles. This is the core Stream-K idea: balance by total work, not
     by whole-tile count.
  5. Sends each worker its batch of (tile, k-range) assignments over
     TCP, collects partial results, and sums partials that share a
     tile across different k-ranges to reconstruct C.
  6. Verifies the result against numpy's A @ B and reports per-worker
     work-unit counts (to demonstrate the even split) plus wall-clock
     time, so this run's numbers can be compared against the other
     algorithm prototypes.
"""
import argparse
import socket
import time
from collections import defaultdict

import numpy as np

from shared import send_msg, recv_msg


def build_tiles(M, N, tile_size):
    """Return list of (tile_row, tile_col, row_start, row_end, col_start, col_end)."""
    tiles = []
    for ti, row_start in enumerate(range(0, M, tile_size)):
        row_end = min(row_start + tile_size, M)
        for tj, col_start in enumerate(range(0, N, tile_size)):
            col_end = min(col_start + tile_size, N)
            tiles.append((ti, tj, row_start, row_end, col_start, col_end))
    return tiles


def streamk_assignments(tiles, K, num_workers):
    """
    Stream-K paper (arXiv:2301.03598) Sec. 4 / Algorithm 5:
    iters_per_cta = ceil(total_iters / g); every worker gets that full
    share except the last, which gets whatever's left over. Linearized
    m -> n -> k, so a share can cross tile boundaries.
    """
    total_units = len(tiles) * K
    iters_per_cta = -(-total_units // num_workers)  # ceil div, per paper

    worker_jobs = [[] for _ in range(num_workers)]
    cursor = 0
    for w in range(num_workers):
        remaining = min(iters_per_cta, total_units - cursor)
        while remaining > 0:
            tile_index = cursor // K
            k_pos = cursor % K
            take = min(remaining, K - k_pos)
            worker_jobs[w].append((tile_index, k_pos, k_pos + take))
            cursor += take
            remaining -= take
    return worker_jobs


def send_to_worker(address, assignments, tiles, A, B):
    host, port = address
    payload = {"assignments": []}
    for tile_index, k_start, k_end in assignments:
        ti, tj, r0, r1, c0, c1 = tiles[tile_index]
        payload["assignments"].append({
            "tile_row": ti, "tile_col": tj,
            "k_start": k_start, "k_end": k_end,
            # Send only the rows/cols this tile needs, full K depth - the worker slices k_start:k_end itself.
            "A_block": A[r0:r1, :].tolist(),
            "B_block": B[:, c0:c1].tolist(),
        })

    with socket.create_connection((host, port), timeout=30) as sock:
        send_msg(sock, payload)
        return recv_msg(sock)["results"]


def main():
    parser = argparse.ArgumentParser(description="Stream-K coordinator (divider + aggregator)")
    parser.add_argument("--M", type=int, default=256)
    parser.add_argument("--K", type=int, default=256)
    parser.add_argument("--N", type=int, default=256)
    parser.add_argument("--tile-size", type=int, default=64)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument(
        "--workers", nargs="+", required=True,
        help="worker addresses as host:port, e.g. --workers localhost:9001 localhost:9002",
    )
    args = parser.parse_args()

    worker_addrs = []
    for w in args.workers:
        host, port = w.split(":")
        worker_addrs.append((host, int(port)))

    rng = np.random.default_rng(args.seed)
    A = rng.random((args.M, args.K))
    B = rng.random((args.K, args.N))

    tiles = build_tiles(args.M, args.N, args.tile_size)
    worker_jobs = streamk_assignments(tiles, args.K, len(worker_addrs))

    # Report the work split BEFORE running, so the even-ness of the distribution is visible regardless of network timing noise.
    print("[coordinator] work-unit distribution (should be ~equal across workers):")
    for w, jobs in enumerate(worker_jobs):
        units = sum(k_end - k_start for _, k_start, k_end in jobs)
        print(f"  worker {w} ({worker_addrs[w][0]}:{worker_addrs[w][1]}): "
              f"{units} units across {len(jobs)} sub-assignment(s)")


    tile_lookup = {(ti, tj): (r0, r1, c0, c1) for ti, tj, r0, r1, c0, c1 in tiles}

    C = np.zeros((args.M, args.N))
    start = time.perf_counter()
    for w, (address, jobs) in enumerate(zip(worker_addrs, worker_jobs)):
        if not jobs:
            continue
        results = send_to_worker(address, jobs, tiles, A, B)
        for r in results:
            ti, tj = r["tile_row"], r["tile_col"]
            r0, r1, c0, c1 = tile_lookup[(ti, tj)]
            C[r0:r1, c0:c1] += np.array(r["partial"])
    elapsed = time.perf_counter() - start

    expected = A @ B
    max_err = float(np.max(np.abs(C - expected)))
    print(f"\n[coordinator] wall-clock time: {elapsed:.4f}s")
    print(f"[coordinator] max abs error vs numpy A@B: {max_err:.2e}")
    print("[coordinator] PASS" if max_err < 1e-6 else "[coordinator] FAIL — check protocol/logic")


if __name__ == "__main__":
    main()

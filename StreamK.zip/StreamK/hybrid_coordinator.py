"""
hybrid_coordinator.py -- "DP + two-tile Stream-K" variant (paper Sec. 5.2),
for direct comparison against coordinator.py (basic Stream-K).

Whole tiles get handed out round-robin first style (plain data-parallel,
no fixup needed -- each worker owns its tile outright). Only the
leftover tiles that don't fill a full round get Stream-K-split, since
that's where basic Stream-K's uneven-tile problem actually shows up.

Same worker.py, same wire protocol, same aggregation logic as
coordinator.py -- only streamk_assignments() is swapped out, so run
it the same way:

  python3 hybrid_coordinator.py --M 512 --K 512 --N 512 --tile-size 128 \
      --workers localhost:9001 localhost:9002 localhost:9003 localhost:9004
"""
import argparse
import socket
import time

import numpy as np

from shared import send_msg, recv_msg
from coordinator import build_tiles, send_to_worker


def hybrid_assignments(tiles, K, num_workers):
    # Paper Sec 5.2: two-tile variant does ONE FEWER full DP wave than
    # the naive floor(t/p), folding that whole extra wave into the
    # Stream-K phase so each Stream-K worker gets >1 tile's worth of
    # work but <2 (not just the small leftover remainder).
    total_tiles = len(tiles)
    naive_full_rounds, leftover = divmod(total_tiles, num_workers)
    full_rounds = max(0, naive_full_rounds - 1) if naive_full_rounds > 0 else 0

    worker_jobs = [[] for _ in range(num_workers)]
    tile_cursor = 0

    # DP phase: whole tiles, round-robin, one owner each -- no fixup.
    for _ in range(full_rounds):
        for w in range(num_workers):
            worker_jobs[w].append((tile_cursor, 0, K))
            tile_cursor += 1

    # Stream-K phase: the held-back DP wave's tiles PLUS the leftover
    # -- num_workers + leftover tiles total, split evenly (ceil rule,
    # last worker gets less), so each worker's share is >1 tile but <2.
    stream_k_tile_count = total_tiles - tile_cursor
    if stream_k_tile_count > 0:
        leftover_tiles = list(range(tile_cursor, total_tiles))
        total_units = stream_k_tile_count * K
        iters_per_cta = -(-total_units // num_workers)
        cursor = 0
        for w in range(num_workers):
            remaining = min(iters_per_cta, total_units - cursor)
            while remaining > 0:
                local_tile = cursor // K
                tile_index = leftover_tiles[local_tile]
                k_pos = cursor % K
                take = min(remaining, K - k_pos)
                worker_jobs[w].append((tile_index, k_pos, k_pos + take))
                cursor += take
                remaining -= take

    return worker_jobs, full_rounds, stream_k_tile_count


def main():
    parser = argparse.ArgumentParser(description="Hybrid DP + two-tile Stream-K coordinator")
    parser.add_argument("--M", type=int, default=256)
    parser.add_argument("--K", type=int, default=256)
    parser.add_argument("--N", type=int, default=256)
    parser.add_argument("--tile-size", type=int, default=64)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--workers", nargs="+", required=True)
    args = parser.parse_args()

    worker_addrs = [(w.split(":")[0], int(w.split(":")[1])) for w in args.workers]

    rng = np.random.default_rng(args.seed)
    A = rng.random((args.M, args.K))
    B = rng.random((args.K, args.N))

    tiles = build_tiles(args.M, args.N, args.tile_size)
    worker_jobs, full_rounds, sk_tiles = hybrid_assignments(tiles, args.K, len(worker_addrs))

    print(f"[hybrid] {len(tiles)} tiles -> {full_rounds} DP round(s), "
          f"{sk_tiles} tile(s) handled via Stream-K split (held-back wave + leftover)")
    for w, jobs in enumerate(worker_jobs):
        units = sum(k_end - k_start for _, k_start, k_end in jobs)
        print(f"  worker {w} ({worker_addrs[w][0]}:{worker_addrs[w][1]}): "
              f"{units} units across {len(jobs)} sub-assignment(s)")

    tile_lookup = {(ti, tj): (r0, r1, c0, c1) for ti, tj, r0, r1, c0, c1 in tiles}
    C = np.zeros((args.M, args.N))
    start = time.perf_counter()
    for address, jobs in zip(worker_addrs, worker_jobs):
        if not jobs:
            continue
        results = send_to_worker(address, jobs, tiles, A, B)
        for r in results:
            r0, r1, c0, c1 = tile_lookup[(r["tile_row"], r["tile_col"])]
            C[r0:r1, c0:c1] += np.array(r["partial"])
    elapsed = time.perf_counter() - start

    expected = A @ B
    max_err = float(np.max(np.abs(C - expected)))
    print(f"\n[hybrid] wall-clock time: {elapsed:.4f}s")
    print(f"[hybrid] max abs error vs numpy A@B: {max_err:.2e}")
    print("[hybrid] PASS" if max_err < 1e-6 else "[hybrid] FAIL")


if __name__ == "__main__":
    main()

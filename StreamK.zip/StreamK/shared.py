"""
shared.py — common wire protocol for the Stream-K prototype.

All messages are length-prefixed JSON: a 8-byte big-endian length header
followed by that many bytes of UTF-8 JSON. Matrices / sub-matrices are
sent as nested lists (JSON has no native array type).
"""
import json
import socket
import struct

HEADER = "!Q"  # unsigned 8-byte length prefix
HEADER_SIZE = struct.calcsize(HEADER)


def send_msg(sock: socket.socket, obj) -> None:
    payload = json.dumps(obj).encode("utf-8")
    sock.sendall(struct.pack(HEADER, len(payload)) + payload)


def _recv_exact(sock: socket.socket, n: int) -> bytes:
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            raise ConnectionError("socket closed before expected bytes arrived")
        buf.extend(chunk)
    return bytes(buf)


def recv_msg(sock: socket.socket):
    (length,) = struct.unpack(HEADER, _recv_exact(sock, HEADER_SIZE))
    payload = _recv_exact(sock, length)
    return json.loads(payload.decode("utf-8"))

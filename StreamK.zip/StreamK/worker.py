"""
worker.py — a "multiplication microservice" container.

Listens on a TCP port. Each connection delivers ONE batch message:

{
  "assignments": [
    {
      "tile_row": int, "tile_col": int,   # which output tile this belongs to
      "k_start": int, "k_end": int,        # Stream-K: only THIS slice of the
                                            #   K (reduction) dimension
      "A_block": [[...]],                  # shape (tile_m, K) — full K kept
      "B_block": [[...]],                  # shape (K, tile_n)   so k-slicing
                                            #   happens locally on the worker
    },
    ...
  ]
}

A worker receives several assignments in one batch because its even
share of total work (Stream-K's whole point) rarely lines up with a
single clean tile. It returns:

{
  "results": [
    {"tile_row": int, "tile_col": int, "k_start": int, "k_end": int,
     "partial": [[...]]},
    ...
  ]
}

Each partial is that worker's contribution to one tile's K-reduction
over its assigned k-range only. The coordinator sums partials that
share (tile_row, tile_col) across different k-ranges to reconstruct full tile.
"""
import argparse
import socketserver
import numpy as np

from shared import recv_msg, send_msg


class WorkerHandler(socketserver.BaseRequestHandler):
    def handle(self):
        msg = recv_msg(self.request)
        results = []
        for job in msg["assignments"]:
            a_block = np.array(job["A_block"], dtype=float)
            b_block = np.array(job["B_block"], dtype=float)
            k_start, k_end = job["k_start"], job["k_end"]

            # The actual unit of work: multiply-accumulate over this
            # worker's assigned slice of the K dimension only — not
            # necessarily the whole tile.
            partial = a_block[:, k_start:k_end] @ b_block[k_start:k_end, :]

            results.append({
                "tile_row": job["tile_row"],
                "tile_col": job["tile_col"],
                "k_start": k_start,
                "k_end": k_end,
                "partial": partial.tolist(),
            })
        send_msg(self.request, {"results": results})


class ThreadingTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True


def main():
    parser = argparse.ArgumentParser(description="Stream-K multiplication worker")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, required=True)
    args = parser.parse_args()

    server = ThreadingTCPServer((args.host, args.port), WorkerHandler)
    print(f"[worker] listening on {args.host}:{args.port}")
    server.serve_forever()


if __name__ == "__main__":
    main()
